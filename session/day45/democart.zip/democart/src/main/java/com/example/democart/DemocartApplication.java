package com.example.democart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemocartApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemocartApplication.class, args);
	}

}
