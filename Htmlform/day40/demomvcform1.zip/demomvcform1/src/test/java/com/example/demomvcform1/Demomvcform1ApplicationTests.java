package com.example.demomvcform1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demomvcform1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
