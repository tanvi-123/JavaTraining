package com.example.demohttpmethods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemohttpmethodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemohttpmethodsApplication.class, args);
	}

}
