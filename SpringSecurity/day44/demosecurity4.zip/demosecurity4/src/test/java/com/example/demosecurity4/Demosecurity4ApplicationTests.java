package com.example.demosecurity4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demosecurity4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
