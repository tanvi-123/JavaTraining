package com.example.demosecurity2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demosecurity2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
