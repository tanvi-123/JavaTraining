package com.example.demosecurity3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demosecurity3Application {

	public static void main(String[] args) {
		SpringApplication.run(Demosecurity3Application.class, args);
	}

}
