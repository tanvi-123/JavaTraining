package com.example.demosecurity3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demosecurity3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
