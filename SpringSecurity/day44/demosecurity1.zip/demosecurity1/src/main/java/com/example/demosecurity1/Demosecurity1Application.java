package com.example.demosecurity1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demosecurity1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demosecurity1Application.class, args);
	}

}
