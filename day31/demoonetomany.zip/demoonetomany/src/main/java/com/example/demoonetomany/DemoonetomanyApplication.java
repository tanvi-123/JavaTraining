package com.example.demoonetomany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoonetomanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoonetomanyApplication.class, args);
	}

}
