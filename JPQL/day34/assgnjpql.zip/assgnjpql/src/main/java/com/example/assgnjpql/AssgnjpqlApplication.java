package com.example.assgnjpql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssgnjpqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssgnjpqlApplication.class, args);
	}

}
