package com.example.assgnjpql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssgnjpqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
